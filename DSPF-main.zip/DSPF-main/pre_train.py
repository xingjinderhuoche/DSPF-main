import os

os.environ['CUDA_VISIBLE_DEVICES'] = '0,1'
import argparse
import os
import numpy as np
import torch
import json
import time
import utils.source_loaders

from easydict import EasyDict as edict
from importlib import import_module
from pprint import pprint
from run_pretrain import Manager_pretrain

import math

from models.our_models import our_model

TRAIN_NAME = os.path.splitext(os.path.basename(__file__))[0]




# Configuration for PCN
def PCNConfig():
    __C = edict()
    cfg = __C

    #
    # Dataset Config
    #
    __C.DATASETS = edict()
    __C.DATASETS.COMPLETION3D = edict()
    __C.DATASETS.COMPLETION3D.CATEGORY_FILE_PATH = './datasets/Completion3D.json'
    __C.DATASETS.COMPLETION3D.PARTIAL_POINTS_PATH = '/path/to/datasets/Completion3D/%s/partial/%s/%s.h5'
    __C.DATASETS.COMPLETION3D.COMPLETE_POINTS_PATH = '/path/to/datasets/Completion3D/%s/gt/%s/%s.h5'
    __C.DATASETS.SHAPENET = edict()
    __C.DATASETS.SHAPENET.CATEGORY_FILE_PATH = './datasets/MineRealComSNData.json'  # MineRealComSNData_chair.json
    __C.DATASETS.SHAPENET.N_RENDERINGS = 1  # 采样点个数
    __C.DATASETS.SHAPENET.N_POINTS = 2048  # 2048

    # __C.DATASETS.SHAPENET.PARTIAL_POINTS_PATH        =  './data/cra/%s/partial/%s/%s/%02d.pcd'
    # __C.DATASETS.SHAPENET.COMPLETE_POINTS_PATH       =  './data/cra/%s/complete/%s/%s.pcd'
    __C.DATASETS.SHAPENET.PARTIAL_POINTS_PATH = '/home/haifeng/xzq/PP/CRA-PCN-main/data/DA/MineRealComSNData/%s/partial/%s/%s/%02d.pcd'
    __C.DATASETS.SHAPENET.COMPLETE_POINTS_PATH = '/home/haifeng/xzq/PP/CRA-PCN-main/data/DA/MineRealComSNData/%s/complete/%s/%s.pcd'

    #
    # Dataset
    #
    __C.DATASET = edict()
    # Dataset Options: Completion3D, ShapeNet, ShapeNetCars, Completion3DPCCT
    __C.DATASET.TRAIN_DATASET = 'PCN'
    __C.DATASET.TEST_DATASET = 'PCN'

    #
    # Constants
    #
    __C.CONST = edict()

    __C.CONST.NUM_WORKERS = 8
    __C.CONST.N_INPUT_POINTS = 2048  # 2048

    #
    # Directories
    #

    __C.DIR = edict()
    __C.DIR.OUT_PATH = 'results/pre_modelnet/'
    __C.DIR.TEST_PATH = 'test/cra'
    __C.CONST.DEVICE = '0,1'


    #
    # Network
    #
    __C.NETWORK = edict()
    __C.NETWORK.UPSAMPLE_FACTORS = [2, 2, 1, 8]  # 16384 [2, 2, 1, 8]
    __C.NETWORK.KP_EXTENTS = [0.1, 0.1, 0.05, 0.025]  # 16384 [0.1, 0.1, 0.05, 0.025]
    #
    # Train
    #
    __C.TRAIN = edict()
    __C.TRAIN.BATCH_SIZE = 50
    __C.TRAIN.N_EPOCHS = 300
    __C.TRAIN.SAVE_FREQ = 25
    __C.TRAIN.LEARNING_RATE = 0.0001  # 0.0001
    __C.TRAIN.LR_MILESTONES = [50, 100, 150, 200, 250]
    __C.TRAIN.LR_DECAY_STEP = 50
    __C.TRAIN.WARMUP_STEPS = 200  # 200
    __C.TRAIN.WARMUP_EPOCHS = 20
    __C.TRAIN.GAMMA = .5
    __C.TRAIN.BETAS = (.9, .999)
    __C.TRAIN.WEIGHT_DECAY = 0
    __C.TRAIN.LR_DECAY = 150

    #
    # Test
    #
    __C.TEST = edict()
    __C.TEST.METRIC_NAME = 'ChamferDistance'

    #
    # mine_model_G
    #
    __C.num_group = 64
    __C.group_size = 32
    __C.mask_ratio = [10, 50, 4]
    __C.feat_dim = 1024
    __C.n_points = 2048
    __C.nbr_ratio = 2.0  # 2
    __C.shape_recon_weight = 1000
    __C.shape_matching_weight = 1000
    __C.latent_weight = 100

    __C.PARTIAL_POINTS_PATH = '/media/haifeng/Data/ZhiQian/11.3前/DA/data/PCN/%s/partial/%s/%s/%02d.pcd'
    __C.COMPLETE_POINTS_PATH = '/media/haifeng/Data/ZhiQian/11.3前/DA/data/PCN/%s/complete/%s/%s.pcd'
    __C.CATEGORY_FILE_PATH = './data/PCN/PCN.json'

    __C.modelnet_PATH = ''



    __C.domain = edict()
   
    __C.domain.category = 'sofa'#'table'
   

    return cfg


def train_net(cfg):
    torch.backends.cudnn.benchmark = True

    train_dataset_loader = utils.source_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TRAIN_DATASET](cfg)
    val_dataset_loader = utils.source_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg)

    train_data_loader = torch.utils.data.DataLoader(dataset=train_dataset_loader.get_dataset(
        utils.source_loaders.DatasetSubset.TRAIN),
        batch_size=cfg.TRAIN.BATCH_SIZE,
        num_workers=cfg.CONST.NUM_WORKERS,
        collate_fn=utils.source_loaders.collate_fn,
        pin_memory=True,
        shuffle=True,
        drop_last=False)
    val_data_loader = torch.utils.data.DataLoader(dataset=val_dataset_loader.get_dataset(
        utils.source_loaders.DatasetSubset.TEST),
        batch_size=cfg.TRAIN.BATCH_SIZE,
        num_workers=cfg.CONST.NUM_WORKERS // 2,
        collate_fn=utils.source_loaders.collate_fn,
        pin_memory=True,
        shuffle=False)

    # Set up folders for logs and checkpoints
    timestr = time.strftime('_Log_%Y_%m_%d_%H_%M_%S', time.gmtime())
    cfg.DIR.OUT_PATH = os.path.join(cfg.DIR.OUT_PATH, TRAIN_NAME + timestr)
    cfg.DIR.CHECKPOINTS = os.path.join(cfg.DIR.OUT_PATH, 'checkpoints')
    cfg.DIR.LOGS = cfg.DIR.OUT_PATH
    print('Saving outdir: {}'.format(cfg.DIR.OUT_PATH))
    if not os.path.exists(cfg.DIR.CHECKPOINTS):
        os.makedirs(cfg.DIR.CHECKPOINTS)

   

    model = our_model()  # or 'CRAPCN_d'
    if torch.cuda.device_count() > 1:  # 检查电脑是否有多块GPU
        print(f"Let's use {torch.cuda.device_count()} GPUs!")
    if torch.cuda.is_available():
        model = torch.nn.DataParallel(model).cuda()

   

    manager = Manager_pretrain(model, cfg)

    # Start training
    best = manager.train(model, train_data_loader, val_data_loader, cfg)
    return best


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


if __name__ == '__main__':

    # Arguments
    parser = argparse.ArgumentParser()
    parser.add_argument('--category', type=str, default='', help='category')
    parser.add_argument('--sourcedata', type=str, default='', help='the path to source data')
    
    args = parser.parse_args()

   
    seed = 1128
    set_seed(seed)
    # print('cuda available ', torch.cuda.is_available())
    cfg = PCNConfig()
    cfg.domain.category = args.category
   
    cfg.PARTIAL_POINTS_PATH = args.sourcedata + '/%s/partial/%s/%s/%02d.pcd'
    cfg.COMPLETE_POINTS_PATH = args.sourcedata + '/%s/complete/%s/%s.pcd'
   
    train_net(cfg)
   


