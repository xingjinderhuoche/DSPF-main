import os
import numpy as np
import torch
from torch.optim.lr_scheduler import StepLR
import time
from tqdm import tqdm
import utils.data_loaders
import utils.helpers
from utils.average_meter import AverageMeter
from utils.metrics import Metrics
from utils.schedular import GradualWarmupScheduler
from utils.loss_utils_clamp import get_loss_clamp, get_loss_mvp, mine_get_loss_clamp_PCN, mine_get_loss_clamp_G,mine_get_loss_clamp_PCN_PM,remove_outlier_points_tensor
from utils.ply import read_ply, write_ply
import pointnet_utils.pc_util as pc_util
from utils.mvp_utils import *
from PIL import Image


from extensions.chamfer_dist import ChamferDistanceL1, ChamferDistanceL2

from models.transformer import Group
# from extensions.chamfer_dist import ChamferDistanceL1
from extensions.pointops.functions import pointops
from timm.models.layers import trunc_normal_
# from emd_ import emd_module



class Manager_pretrain:
    # Initialization methods
    # ------------------------------------------------------------------------------------------------------------------
    def __init__(self, model, cfg):
        """
        Initialize parameters and start training/testing
        :param model: network object
        :param cfg: configuration object
        """

        ############
        # Parameters
        ############

        # Epoch index
        self.epoch = 0

        # Create the optimizers
        self.optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()),
                                          lr=cfg.TRAIN.LEARNING_RATE,
                                          weight_decay=cfg.TRAIN.WEIGHT_DECAY,
                                          betas=cfg.TRAIN.BETAS)


        self.scheduler_steplr = StepLR(self.optimizer, step_size=1, gamma=0.1 ** (1 / cfg.TRAIN.LR_DECAY))
        self.lr_scheduler = GradualWarmupScheduler(self.optimizer, multiplier=1, total_epoch=cfg.TRAIN.WARMUP_EPOCHS,
                                                   after_scheduler=self.scheduler_steplr)



        # record file
        self.train_record_file = open(os.path.join(cfg.DIR.LOGS, 'training.txt'), 'w')
        self.test_record_file = open(os.path.join(cfg.DIR.LOGS, 'testing.txt'), 'w')

        # eval metric
        self.best_metrics = float('inf')
        self.best_epoch = 0




    # Record functions
    def train_record(self, info, show_info=True):
        if show_info:
            print(info)
        if self.train_record_file:
            self.train_record_file.write(info + '\n')
            self.train_record_file.flush()

    def test_record(self, info, show_info=True):
        if show_info:
            print(info)
        if self.test_record_file:
            self.test_record_file.write(info + '\n')
            self.test_record_file.flush()

    def train(self, model, train_data_loader, val_data_loader, cfg):
        

        init_epoch = 0
        steps = 0

        # training record file
        print('Training Record:')
        self.train_record('CD_loss')
        print('Testing Record:')
        self.test_record('#epoch CD_loss')

        num_0 = 0

        # Training Start
        for epoch_idx in range(init_epoch + 1, cfg.TRAIN.N_EPOCHS + 1):

            self.epoch = epoch_idx

            # timer
            epoch_start_time = time.time()

            model.train()


            # Update learning rate
            self.lr_scheduler.step()


            # total cds
            total_cd = 0
            total_ploss = 0
            total_closs = 0



            batch_end_time = time.time()
            n_batches = len(train_data_loader)



            learning_rate = self.optimizer.param_groups[0]['lr']

            for batch_idx,  data in enumerate(train_data_loader):# data

                for k, v in data.items():
                    data[k] = utils.helpers.var_or_cuda(v)


                # unpack data
                partial = data['partial']
                gt = data['complete']
                
                p_loss = 0

                course_c = model(partial)

               

                c_loss = mine_get_loss_clamp_PCN(course_c, gt, sqrt=True)


                loss_total = c_loss

                self.optimizer.zero_grad()
                loss_total.backward()
                self.optimizer.step()


                cd_item = loss_total
                total_cd += cd_item
                ploss_item = p_loss
                total_ploss += ploss_item
                closs_item = c_loss
                total_closs += closs_item


                n_itr = (epoch_idx - 1) * n_batches + batch_idx

                # training record
                message = '{:d} {:.4f} {:.4f}'.format(n_itr,cd_item, total_cd)
                self.train_record(message, show_info=False)


            # avg cds
            avg_cd = total_cd / n_batches
            avg_ploss = total_ploss / n_batches
            avg_closs = total_closs/ n_batches


            epoch_end_time = time.time()

            # Training record
            self.train_record(
                '[Epoch %d/%d] LearningRate = %f EpochTime = %.3f (s) Losses = %f p_Losses = %f c_Losses = %f ' %
                (epoch_idx, cfg.TRAIN.N_EPOCHS, learning_rate, epoch_end_time - epoch_start_time,
                 avg_cd,avg_ploss, avg_closs))

            # Validate the current model
            cd_eval = self.validate(cfg, model=model, val_data_loader=val_data_loader)

            # Save checkpoints
            if cd_eval < self.best_metrics:
                self.best_epoch = epoch_idx
                file_name = 'ckpt-best.pth' if cd_eval < self.best_metrics else 'ckpt-epoch-%03d.pth' % epoch_idx
                output_path = os.path.join(cfg.DIR.CHECKPOINTS, file_name)
                torch.save({
                    'epoch_index': epoch_idx,
                    'best_metrics': cd_eval,
                    'model': model.state_dict()
                }, output_path)

                print('Saved checkpoint to %s ...' % output_path)

                if cd_eval < self.best_metrics:
                    self.best_metrics = cd_eval

        # training end
        self.train_record_file.close()
        self.test_record_file.close()
        return self.best_metrics

    def validate(self, cfg, model=None, val_data_loader=None, outdir=None):
        # Enable the inbuilt cudnn auto-tuner to find the best algorithm to use
        torch.backends.cudnn.benchmark = True

        # Switch models to evaluation mode
        model.eval()

        n_samples = len(val_data_loader)
        test_losses = AverageMeter(['cdc'])
        test_metrics = AverageMeter(Metrics.names())

        # Start testing
        for model_idx, data in enumerate(val_data_loader):

            with torch.no_grad():
                for k, v in data.items():
                    data[k] = utils.helpers.var_or_cuda(v)

                # unpack data
               
                partial = data['partial']
                gt = data['complete']
                # gt = data['sc_cloud']
                # print("---pcv:", partial.shape)
                # print("---gcv:", gt.shape)

               
                
                course = model(partial)

                loss_total = mine_get_loss_clamp_PCN(course, gt, sqrt=False)

                _metrics = [loss_total]
                test_losses.update([loss_total])
                test_metrics.update(_metrics)

        # Record testing results
        message = '#{:d} {:.4f}  | #{:d} {:.4f}'.format(self.epoch,test_losses.avg(0), self.best_epoch, self.best_metrics)
        self.test_record(message)

        return test_losses.avg(0)


    def testone(self, cfg, model=None, test_data_loader=None, outdir=None):
        # Enable the inbuilt cudnn auto-tuner to find the best algorithm to use
        torch.backends.cudnn.benchmark = True

        # Switch models to evaluation mode
        model.eval()

        n_samples = len(test_data_loader)
        test_losses = AverageMeter(['cdc'])
        test_metrics = AverageMeter(Metrics.names())
        category_metrics = dict()
        category_models = dict()

        # Start testing
        for model_idx, (taxonomy_id, model_id, data) in enumerate(test_data_loader):
            taxonomy_id = taxonomy_id[0] if isinstance(taxonomy_id[0], str) else taxonomy_id[0].item()
            # model_id = model_id[0]

            with torch.no_grad():
                for k, v in data.items():
                    data[k] = utils.helpers.var_or_cuda(v)

                partial = data['partial_cloud']

                b, n, _ = partial.shape

                pcds_pred = model(partial.contiguous())


                # output to file
                if outdir:
                    if not os.path.exists(os.path.join(outdir, taxonomy_id)):
                        os.makedirs(os.path.join(outdir, taxonomy_id))
                    if not os.path.exists(os.path.join(outdir, taxonomy_id + '_images')):
                        os.makedirs(os.path.join(outdir, taxonomy_id + '_images'))
                    # save pred, gt, partial pcds
                    pred = pcds_pred
                    for mm, model_name in enumerate(model_id):
                        output_file = os.path.join(outdir, taxonomy_id, model_name)
                        write_ply(output_file + '_pred.ply', pred[mm, :].detach().cpu().numpy(), ['x', 'y', 'z'])
                        write_ply(output_file + '_partial.ply', partial[mm, :].detach().cpu().numpy(), ['x', 'y', 'z'])
