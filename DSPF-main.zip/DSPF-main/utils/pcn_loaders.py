import json
import logging
import numpy as np
import random
import torch.utils.data.dataset
import open3d as o3d
import utils.data_transforms
from enum import Enum, unique
from tqdm import tqdm
from utils.io import IO
import os
import glob

# label_mapping = {
#     3: '03001627',
#     6: '04379243',
#     5: '04256520',
#     1: '02933112',
#     4: '03636649',
#     2: '02958343',
#     0: '02691156',
#     7: '04530566'
# }
label_mapping = {
    0: '02691156',
    1: '02933112'
}

# label_mapping = {
#     0: '03001627',
# }

@unique
class DatasetSubset(Enum):
    TRAIN = 0
    TEST = 1
    VAL = 2


def collate_fn(batch):

    data = {}

    for sample in batch:
        _data = sample
        for k, v in _data.items():
            if k not in data:
                data[k] = []
            data[k].append(v)

    for k, v in data.items():
        if k == 'source_index':  # 特殊处理整数索引
            data[k] = torch.tensor(v, dtype=torch.long)  # 转换为长整型张量
        else:
            data[k] = torch.stack(v, 0)  # 对其他数据使用 torch.stack

    # for k, v in data.items():
    #     data[k] = torch.stack(v, 0)
    # print("data_s_index.shape", data['source_index'].shape)
    # print("data.shape", data['tc_cloud'].shape)

    return data


code_mapping = {
    'plant': '02691156',
    'cabinet': '02933112',
}
# code_mapping = {
#      'chair': '03001627',
#  }

# code_mapping = {
#     'plant': '02691156',
#     'cabinet': '02933112',
#     'car': '02958343',
#     'chair': '03001627',
#     'lamp': '03636649',
#     'couch': '04256520',
#     'table': '04379243',
#     'watercraft': '04530566',
# }

def read_ply(file_path):
    pc = o3d.io.read_point_cloud(file_path)
    ptcloud = np.array(pc.points)
    return ptcloud


class Dataset(torch.utils.data.dataset.Dataset):
    def __init__(self, options, tp_list, tc_list, sc_list, subset,transforms=None):
        self.options = options
        self.transforms = transforms
        self.cache = dict()

        self.tp_list = tp_list
        self.tc_list = tc_list
        self.sc_list = sc_list


        self.s_len = len(self.sc_list)
        self.s_idx = self.s_len
        self.s_index = list(range(self.s_len))
        np.random.shuffle(self.s_index)
        self.subset = subset
        self.n_renderings = 8 if self.subset == 'train' else 1

    def get_s_index(self):
        if self.s_idx >= self.s_len:
            self.s_idx = 0

            np.random.shuffle(self.s_index)

        res = self.s_index[self.s_idx]

        self.s_idx += 1
        return res


    def __len__(self):
        return len(self.tc_list)

    def __getitem__(self, idx):
        # sample = self.file_list[idx]
        # gt_sample = self.gt_list[idx]
        rand_idx = random.randint(0, self.n_renderings - 1) if self.subset == 'train' else 0
        tc_sample = self.tc_list[idx]
        tp_sample = self.tp_list[idx][rand_idx]
        source_index = self.get_s_index()
        sc_sample = self.sc_list[source_index]

        data = {}
        data['tc_cloud'] = IO.get(tc_sample).astype(np.float32)
        data['tp_cloud'] = IO.get(tp_sample).astype(np.float32)
        data['sc_cloud'] = IO.get(sc_sample).astype(np.float32)
        #top_message
        data['source_index'] = source_index

        # apply transforms
        if self.transforms is not None:
            data = self.transforms(data)

        return data

class PCN(object):
    # def __init__(self, data_root, subset, class_choice = None):
    def __init__(self, config):
        self.partial_points_path = config.PARTIAL_POINTS_PATH
        self.complete_points_path = config.COMPLETE_POINTS_PATH
        self.category_file = config.CATEGORY_FILE_PATH
        self.npoints = config.CONST.N_INPUT_POINTS
        self.categories = config.domain.category
        self.cfg = config

        self.epn_category_file = config.EPN_CATEGORY_FILE_PATH
        self.epn_partial_points_path = config.EPN_PARTIAL_POINTS_PATH
        self.epn_complete_points_path = config.EPN_COMPLETE_POINTS_PATH
        self.train_mode = config.train_mode

        # Load the dataset indexing file
        self.dataset_categories = []
        with open(self.category_file) as f:
            self.dataset_categories = json.loads(f.read())
            self.dataset_categories = [dc for dc in self.dataset_categories if dc['taxonomy_name'] in self.categories]


        self.epn_dataset_categories = []
        with open(self.epn_category_file) as f:
            self.epn_dataset_categories = json.loads(f.read())
            self.epn_dataset_categories = [dc for dc in self.epn_dataset_categories if dc['taxonomy_name'] in self.categories]

        # self.file_list = self._get_file_list(self.subset, self.n_renderings)
        # self.transforms = self._get_transforms(self.subset)

    def get_dataset(self, subset):
        print('getsubset',self._get_subset(subset))
        self.n_renderings = 8 if self._get_subset(subset) == 'train' else 1
        tp_list, tc_list, sc_list = self._get_file_list(self._get_subset(subset), self.n_renderings)
        transforms = self._get_transforms(self._get_subset(subset))
        return Dataset({
            'required_items': ['tc_cloud', 'tp_cloud','sc_cloud','source_index'],
            'shuffle': subset == DatasetSubset.TRAIN
        }, tp_list, tc_list, sc_list, self._get_subset(subset), transforms)


    def _get_transforms(self, subset):
        if subset == 'train':
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['tp_cloud', 'tc_cloud', 'sc_cloud']
            }, {
                'callback': 'RandomMirrorPoints',
                'objects': ['tp_cloud', 'tc_cloud', 'sc_cloud']
            },{
                'callback': 'ToTensor',
                'objects': ['tp_cloud', 'tc_cloud', 'sc_cloud']
            }])
        else:
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['tp_cloud']
            }, {
                'callback': 'ToTensor',
                'objects': ['tp_cloud', 'tc_cloud', 'sc_cloud']
            }])

    def _get_subset(self, subset):
        if subset == DatasetSubset.TRAIN:
            return 'train'
        elif subset == DatasetSubset.VAL:
            return 'val'
        else:
            return 'test'

    def _get_file_list(self, subset, n_renderings=1):
        """Prepare file list for the dataset"""
        # file_list = []
        tp_list = []  # target partial
        tc_list = []  # target complete
        tc_shuffled_list = []

        for dc in self.dataset_categories:
            print('Collecting files of Taxonomy [ID=%s, Name=%s]' % (dc['taxonomy_id'], dc['taxonomy_name']))
            print('subset', subset)
            samples = dc[subset]

            for s in samples:
                tp_list.append([
                        self.partial_points_path % (subset, dc['taxonomy_id'], s, i)
                        for i in range(n_renderings)
                    ])
                tc_list.append(self.complete_points_path % (subset, dc['taxonomy_id'], s))
                # file_list.append({
                #     'taxonomy_id':
                #     dc['taxonomy_id'],
                #     'model_id':
                #     s,
                #     'partial_path': [
                #         self.partial_points_path % (subset, dc['taxonomy_id'], s, i)
                #         for i in range(n_renderings)
                #     ],
                #     'gt_path':
                #     self.complete_points_path % (subset, dc['taxonomy_id'], s),
                # })

        if self.train_mode == 'unpair' and subset == 'train':
            print('using unpaired mode')
            random.shuffle(tc_list)
        print(f'using {self.train_mode} mode')

        print('Complete collecting files of the target complete dataset. Total files: %d' % len(tc_list))
        print('Complete collecting files of the target partial dataset. Total files: %d' % len(tp_list))

        sp_list = []
        sc_list = []  # 另外的数据集 source complete

        for dc in self.epn_dataset_categories:
            print('Collecting epn files of Taxonomy [ID=%s, Name=%s]' % (dc['taxonomy_id'], dc['taxonomy_name']))
            category_name = dc['taxonomy_name']
            partial_samples = dc[subset]['partial']
            complete_samples = dc[subset]['complete']

            for (partial_file, complete_file) in zip(partial_samples, complete_samples):
                # file_list['taxonomy_id'].append(dc['taxonomy_id'])
                # file_list['model_id'].append(complete_file)
                sp_list.append(self.epn_partial_points_path % (category_name, partial_file))
                sc_list.append(self.epn_complete_points_path % (category_name, complete_file))


        # sc_list = glob.glob(os.path.join(self.cfg.domain.source, self.cfg.domain.category, 'complete', '*.pcd'))
        print('Complete collecting files of the source dataset. Total files: %d' % len(sc_list))

        return tp_list, tc_list, sc_list

    # def __getitem__(self, idx):
    #     sample = self.file_list[idx]
    #     data = {}
    #     rand_idx = random.randint(0, self.n_renderings - 1) if self.subset=='train' else 0
    #
    #     for ri in ['partial', 'gt']:
    #         file_path = sample['%s_path' % ri]
    #         if type(file_path) == list:
    #             file_path = file_path[rand_idx]
    #         data[ri] = IO.get(file_path).astype(np.float32)
    #
    #     assert data['gt'].shape[0] == self.npoints
    #
    #     if self.transforms is not None:
    #         data = self.transforms(data)
    #
    #     return sample['taxonomy_id'], sample['model_id'], (data['partial'], data['gt'])
    #
    # def __len__(self):
    #     return len(self.file_list)




class MineRealComDataLoader(object):
    def __init__(self, cfg):
        self.cfg = cfg
        self.datamode = cfg.DATASET.MODE


    def get_dataset(self, subset):
        tp_list, tc_list, sc_list = self._get_file_list(self.cfg)
        transforms = self._get_transforms(self.cfg, subset)
        return Dataset({
            'required_items': ['tc_cloud', 'tp_cloud','sc_cloud','source_index'],
            'shuffle': subset == DatasetSubset.TRAIN
        }, tp_list, tc_list, sc_list,  transforms)

    def _get_transforms(self, cfg, subset):
        if subset == DatasetSubset.TRAIN:
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': cfg.CONST.N_INPUT_POINTS
                },
                'objects': ['tp_cloud']
            }, {
                'callback': 'RandomMirrorPoints',
                'objects': ['tp_cloud', 'tc_cloud', 'sc_cloud']
            }, {
                'callback': 'ToTensor',
                'objects': ['tp_cloud', 'tc_cloud', 'sc_cloud']
            }])
        else:
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': cfg.CONST.N_INPUT_POINTS
                },
                'objects': ['tp_cloud']
            }, {
                'callback': 'ToTensor',
                'objects': ['tp_cloud', 'tc_cloud', 'sc_cloud']
            }])

    def _get_subset(self, subset):
        if subset == DatasetSubset.TRAIN:
            return 'train'
        elif subset == DatasetSubset.VAL:
            return 'val'
        else:
            return 'test'

    def _get_file_list(self, cfg):
        """Prepare file list for the dataset"""
        tp_list = []#target partial
        tc_list = []#target complete
        sc_list = []#另外的数据集 source complete

        tc_list = glob.glob(os.path.join(cfg.domain.target, cfg.domain.category, 'complete', '*.pcd'))
        print("cfg.domain.target", cfg.domain.target)
        print("cfg.domain.category", cfg.domain.category)
        print('Complete collecting files of the target complete dataset. Total files: %d' % len(tc_list))
        for tc in tc_list:
            tp_name = tc.split('/')[-1].split('.')[0] + "__0__.pcd"
            # print("tp_name", tp_name)
            tp = os.path.join(cfg.domain.target, cfg.domain.category, 'partial', tp_name)
            tp_list.append(tp)
        print('Complete collecting files of the target partial dataset. Total files: %d' % len(tp_list))
        sc_list = glob.glob(os.path.join(cfg.domain.source, cfg.domain.category, 'complete', '*.pcd'))
        print('Complete collecting files of the source dataset. Total files: %d' % len(sc_list))
        # print('test tc[0]:', tc_list[25])
        # print('test tp[0]:', tp_list[25])


        return tp_list, tc_list, sc_list


# //////////////////////////////////////////// = Dataset Loader Mapping = //////////////////////////////////////////// #

DATASET_LOADER_MAPPING = {

    'pcn':PCN,


}  # yapf: disable