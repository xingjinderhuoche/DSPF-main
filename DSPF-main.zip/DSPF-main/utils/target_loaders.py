import json
import logging
import numpy as np
import random
import torch.utils.data.dataset
import open3d as o3d
import utils.data_transforms
from enum import Enum, unique
from tqdm import tqdm
from utils.io import IO
import os
import glob


@unique
class DatasetSubset(Enum):
    TRAIN = 0
    TEST = 1
    VAL = 2


def collate_fn(batch):

    data = {}

    for sample in batch:
        _data = sample
        for k, v in _data.items():
            if k not in data:
                data[k] = []
            data[k].append(v)

    for k, v in data.items():
        data[k] = torch.stack(v, 0)  # 对其他数据使用 torch.stack


    return data




def read_ply(file_path):
    pc = o3d.io.read_point_cloud(file_path)
    ptcloud = np.array(pc.points)
    return ptcloud


class Dataset(torch.utils.data.dataset.Dataset):
    def __init__(self, options, tp_list, tc_list, subset,transforms=None):
        self.options = options
        self.transforms = transforms
        self.cache = dict()

        self.tp_list = tp_list
        self.tc_list = tc_list




        self.subset = subset



    def __len__(self):
        return len(self.tc_list)

    def __getitem__(self, idx):

        tc_sample = self.tc_list[idx]
        tp_sample = self.tp_list[idx]


        data = {}
        data['complete'] = IO.get(tc_sample).astype(np.float32)
        data['partial'] = IO.get(tp_sample).astype(np.float32)

        # apply transforms
        if self.transforms is not None:
            data = self.transforms(data)

        return data

class EPN(object):
    # def __init__(self, data_root, subset, class_choice = None):
    def __init__(self, config):
        self.partial_points_path = config.PARTIAL_POINTS_PATH
        self.complete_points_path = config.COMPLETE_POINTS_PATH
        self.category_file = config.CATEGORY_FILE_PATH
        self.npoints = config.CONST.N_INPUT_POINTS
        self.categories = config.domain.category
        self.cfg = config

        # self.epn_category_file = config.EPN_CATEGORY_FILE_PATH
        # self.epn_partial_points_path = config.EPN_PARTIAL_POINTS_PATH
        # self.epn_complete_points_path = config.EPN_COMPLETE_POINTS_PATH
        # self.train_mode = config.train_mode

        # Load the dataset indexing file
        self.dataset_categories = []
        with open(self.category_file) as f:
            self.dataset_categories = json.loads(f.read())
            self.dataset_categories = [dc for dc in self.dataset_categories if dc['taxonomy_name'] in self.categories]


        # self.epn_dataset_categories = []
        # with open(self.epn_category_file) as f:
        #     self.epn_dataset_categories = json.loads(f.read())
        #     self.epn_dataset_categories = [dc for dc in self.epn_dataset_categories if dc['taxonomy_name'] in self.categories]

        # self.file_list = self._get_file_list(self.subset, self.n_renderings)
        # self.transforms = self._get_transforms(self.subset)

    def get_dataset(self, subset):
        print('getsubset',self._get_subset(subset))

        tp_list, tc_list = self._get_file_list(self._get_subset(subset))
        transforms = self._get_transforms(self._get_subset(subset))
        return Dataset({
            'required_items': ['partial', 'complete'],
            'shuffle': subset == DatasetSubset.TRAIN
        }, tp_list, tc_list, self._get_subset(subset), transforms)


    def _get_transforms(self, subset):
        if subset == 'train':
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['partial', 'complete']
            }, {
                'callback': 'RandomMirrorPoints',
                'objects': ['partial', 'complete']
            },{
                'callback': 'ToTensor',
                'objects': ['partial', 'complete']
            }])
        else:
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['partial']
            }, {
                'callback': 'ToTensor',
                'objects': ['partial', 'complete']
            }])

    def _get_subset(self, subset):
        if subset == DatasetSubset.TRAIN:
            return 'train'
        elif subset == DatasetSubset.VAL:
            return 'val'
        else:
            return 'test'

    def _get_file_list(self, subset):
        """Prepare file list for the dataset"""

        tp_list = []
        tc_list = []  # 另外的数据集 source complete

        for dc in self.dataset_categories:
            print('Collecting epn files of Taxonomy [ID=%s, Name=%s]' % (dc['taxonomy_id'], dc['taxonomy_name']))
            category_name = dc['taxonomy_name']
            partial_samples = dc[subset]['partial']
            complete_samples = dc[subset]['complete']

            for (partial_file, complete_file) in zip(partial_samples, complete_samples):
                if partial_file.endswith('__0__'):
                    # print('partial file:', partial_file)
                    # print('complete file:', complete_file)
                    tp_list.append(self.partial_points_path % (category_name, partial_file))
                    tc_list.append(self.complete_points_path % (category_name, complete_file))


        # sc_list = glob.glob(os.path.join(self.cfg.domain.source, self.cfg.domain.category, 'complete', '*.pcd'))
        print('collecting :',subset)
        print('Complete collecting files of the target dataset. Total files: %d' % len(tc_list))

        return tp_list, tc_list

#####################
class ModelNet(object):
    # def __init__(self, data_root, subset, class_choice = None):
    def __init__(self, config):
        self.modelnet_dataset_path = config.modelnet_PATH
        # self.complete_points_path = config.COMPLETE_POINTS_PATH
        # self.category_file = config.CATEGORY_FILE_PATH
        self.npoints = config.CONST.N_INPUT_POINTS
        self.categories = config.domain.category
        self.cfg = config

        # self.epn_category_file = config.EPN_CATEGORY_FILE_PATH
        # self.epn_partial_points_path = config.EPN_PARTIAL_POINTS_PATH
        # self.epn_complete_points_path = config.EPN_COMPLETE_POINTS_PATH
        # self.train_mode = config.train_mode

        # Load the dataset indexing file
        # self.dataset_categories = []
        # with open(self.category_file) as f:
        #     self.dataset_categories = json.loads(f.read())
        #     self.dataset_categories = [dc for dc in self.dataset_categories if dc['taxonomy_name'] in self.categories]


        # self.epn_dataset_categories = []
        # with open(self.epn_category_file) as f:
        #     self.epn_dataset_categories = json.loads(f.read())
        #     self.epn_dataset_categories = [dc for dc in self.epn_dataset_categories if dc['taxonomy_name'] in self.categories]

        # self.file_list = self._get_file_list(self.subset, self.n_renderings)
        # self.transforms = self._get_transforms(self.subset)

    def get_dataset(self, subset):
        print('getsubset',self._get_subset(subset))

        tp_list, tc_list = self._get_file_list(self._get_subset(subset))
        transforms = self._get_transforms(self._get_subset(subset))
        return Dataset({
            'required_items': ['partial', 'complete'],
            'shuffle': subset == DatasetSubset.TRAIN
        }, tp_list, tc_list, self._get_subset(subset), transforms)


    def _get_transforms(self, subset):
        if subset == 'train':
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['partial', 'complete']
            }, {
                'callback': 'RandomMirrorPoints',
                'objects': ['partial', 'complete']
            },{
                'callback': 'ToTensor',
                'objects': ['partial', 'complete']
            }])
        else:
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['partial']
            }, {
                'callback': 'ToTensor',
                'objects': ['partial', 'complete']
            }])

    def _get_subset(self, subset):
        if subset == DatasetSubset.TRAIN:
            return 'train'
        else:
            return 'test'

    def _get_file_list(self, subset):
        """Prepare file list for the dataset"""

        tp_list = []
        tc_list = []  # 另外的数据集 source complete


        save_path_gt = os.path.join(self.modelnet_dataset_path, self.categories, subset)
        f_gt = glob.glob(os.path.join(save_path_gt, '*complete.npy'))

        for i in f_gt:
            tc_list.append(i)
            tp_list.append(i.replace('complete.npy', 'partial.npy'))


        print('Complete collecting files of the target dataset. Total files: %d' % len(tc_list))

        return tp_list, tc_list

class PCN(object):
    # def __init__(self, data_root, subset, class_choice = None):
    def __init__(self, config):
        self.partial_points_path = config.PARTIAL_POINTS_PATH
        self.complete_points_path = config.COMPLETE_POINTS_PATH
        self.category_file = config.CATEGORY_FILE_PATH
        self.npoints = config.CONST.N_INPUT_POINTS
        self.categories = config.domain.category
        self.cfg = config



        # Load the dataset indexing file
        self.dataset_categories = []
        with open(self.category_file) as f:
            self.dataset_categories = json.loads(f.read())
            self.dataset_categories = [dc for dc in self.dataset_categories if dc['taxonomy_name'] in self.categories]




    def get_dataset(self, subset):
        print('getsubset',self._get_subset(subset))
        self.n_renderings = 8 if self._get_subset(subset) == 'train' else 1
        tp_list, tc_list = self._get_file_list(self._get_subset(subset), self.n_renderings)
        transforms = self._get_transforms(self._get_subset(subset))
        return Dataset({
            'required_items': ['complete', 'partial'],
            'shuffle': subset == DatasetSubset.TRAIN
        }, tp_list, tc_list, self._get_subset(subset), transforms)


    def _get_transforms(self, subset):
        if subset == 'train':
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['partial', 'complete']
            }, {
                'callback': 'RandomMirrorPoints',
                'objects': ['partial', 'complete']
            },{
                'callback': 'ToTensor',
                'objects': ['partial', 'complete']
            }])
        else:
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['partial']
            }, {
                'callback': 'ToTensor',
                'objects': ['partial', 'complete']
            }])

    def _get_subset(self, subset):
        if subset == DatasetSubset.TRAIN:
            return 'train'
        elif subset == DatasetSubset.VAL:
            return 'val'
        else:
            return 'test'

    def _get_file_list(self, subset, n_renderings=1):
        """Prepare file list for the dataset"""

        tp_list = []  # target partial
        tc_list = []  # target complete


        for dc in self.dataset_categories:
            # print('Collecting files of Taxonomy [ID=%s, Name=%s]' % (dc['taxonomy_id'], dc['taxonomy_name']))
            print('collecting pcn subset', subset)
            samples = dc[subset]

            for s in samples:
                tp_list.append(self.partial_points_path % (subset, dc['taxonomy_id'], s, 0))
                tc_list.append(self.complete_points_path % (subset, dc['taxonomy_id'], s))


        print(f'Complete collecting PCN {subset} files. Total files:{len(tp_list)}')


        return tp_list, tc_list


class unpair(object):
    # def __init__(self, data_root, subset, class_choice = None):
    def __init__(self, config):
        self.partial_points_path = config.PARTIAL_POINTS_PATH
        self.complete_points_path = config.COMPLETE_POINTS_PATH
        self.category_file = config.CATEGORY_FILE_PATH
        self.npoints = config.CONST.N_INPUT_POINTS
        self.categories = config.domain.category
        self.cfg = config

        self.modelnet_dataset_path = config.modelnet_PATH



        # Load the dataset indexing file
        self.dataset_categories = []
        with open(self.category_file) as f:
            self.dataset_categories = json.loads(f.read())
            self.dataset_categories = [dc for dc in self.dataset_categories if dc['taxonomy_name'] in self.categories]



    def get_dataset(self, subset):
        print('getsubset',self._get_subset(subset))
        self.n_renderings = 8 if self._get_subset(subset) == 'train' else 1
        tp_list, tc_list = self._get_file_list(self._get_subset(subset), self.n_renderings)
        transforms = self._get_transforms(self._get_subset(subset))
        return Dataset({
            'required_items': ['complete', 'partial'],
            'shuffle': subset == DatasetSubset.TRAIN
        }, tp_list, tc_list, self._get_subset(subset), transforms)


    def _get_transforms(self, subset):
        if subset == 'train':
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['partial', 'complete']
            }, {
                'callback': 'RandomMirrorPoints',
                'objects': ['partial', 'complete']
            },{
                'callback': 'ToTensor',
                'objects': ['partial', 'complete']
            }])
        else:
            return utils.data_transforms.Compose([{
                'callback': 'RandomSamplePoints',
                'parameters': {
                    'n_points': 2048
                },
                'objects': ['partial']
            }, {
                'callback': 'ToTensor',
                'objects': ['partial', 'complete']
            }])

    def _get_subset(self, subset):
        if subset == DatasetSubset.TRAIN:
            return 'train'
        elif subset == DatasetSubset.VAL:
            return 'val'
        else:
            return 'test'

    def _get_file_list(self, subset, n_renderings=1):
        """Prepare file list for the dataset"""

        tp_list = []  # target partial
        tc_list = []  # target complete


        for dc in self.dataset_categories:
            print('Collecting pcn files of Taxonomy [ID=%s, Name=%s]' % (dc['taxonomy_id'], dc['taxonomy_name']))
            print('subset', subset)
            samples = dc[subset]

            for s in samples:
                tp_list.append(self.partial_points_path % (subset, dc['taxonomy_id'], s, 0))
                tc_list.append(self.complete_points_path % (subset, dc['taxonomy_id'], s))

        print('Complete collecting-- pcn --files of the target complete dataset. Total files: %d' % len(tc_list))


        save_path_gt = os.path.join(self.modelnet_dataset_path, self.categories, subset)
        f_gt = glob.glob(os.path.join(save_path_gt, '*complete.npy'))

        for i in f_gt:
            tc_list.append(i)
            tp_list.append(i.replace('complete.npy', 'partial.npy'))


        print('Complete collecting all files. Total files: %d' % len(tc_list))


        return tp_list, tc_list


# //////////////////////////////////////////// = Dataset Loader Mapping = //////////////////////////////////////////// #

DATASET_LOADER_MAPPING = {

    'epn':EPN,
    'ModelNet':ModelNet,
    'unpair':unpair,
    'PCN':PCN

}  # yapf: disable