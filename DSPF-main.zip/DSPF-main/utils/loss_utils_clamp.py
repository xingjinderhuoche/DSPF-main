import torch
import torch.nn as nn
import torch.nn.functional as F
import open3d as o3d
from extensions.pointops.functions import pointops
import numpy as np

from Chamfer3D.dist_chamfer_3D import chamfer_3DDist
from models.utils import fps_subsample
chamfer_dist = chamfer_3DDist()


def chamfer(p1, p2):
    d1, d2, _, _ = chamfer_dist(p1, p2)
    return torch.mean(d1) + torch.mean(d2)

def chamfer_sqrt(p1, p2):
    d1, d2, _, _ = chamfer_dist(p1, p2)
    d1 = torch.clamp(d1, min=1e-9)
    d2 = torch.clamp(d2, min=1e-9)
    d1 = torch.mean(torch.sqrt(d1))
    d2 = torch.mean(torch.sqrt(d2))
    return (d1 + d2) / 2

def chamfer_single_side(pcd1, pcd2):
    d1, d2, _, _ = chamfer_dist(pcd1, pcd2)
    d1 = torch.mean(d1)
    return d1

def chamfer_single_side_sqrt(pcd1, pcd2):
    d1, d2, _, _ = chamfer_dist(pcd1, pcd2)
    d1 = torch.clamp(d1, min=1e-9)
    d2 = torch.clamp(d2, min=1e-9)
    d1 = torch.mean(torch.sqrt(d1))
    return d1

def get_loss_mvp(pcds_pred, partial, gt, sqrt=True):
    """loss function
    Args
        pcds_pred: List of predicted point clouds, order in [Pc, P1, P2, P3...]
    """
    if sqrt:
        CD = chamfer_sqrt
        PM = chamfer_single_side_sqrt
    else:
        CD = chamfer
        PM = chamfer_single_side

    #-------------------pyramid-----------------------#
    Pc, P1, P2 = pcds_pred
    
    gt_2 = gt
    gt_1 = fps_subsample(gt_2, P1.shape[1])
    gt_c = fps_subsample(gt_1, Pc.shape[1])

    

    cdc = CD(Pc, gt_c) 
    cd1 = CD(P1, gt_1) 
    cd2 = CD(P2, gt_2) 
    cd3 = cd2

    loss_decoder = cdc + cd1 + cd2


    partial_matching = cdc #PM(partial, P1)
    

    loss_all = (loss_decoder) * 1e3 



    losses = [cdc, cd1, cd2, cd3, partial_matching]
    return loss_all, losses, [gt, gt_c, gt_c]

def get_loss_clamp(pcds_pred, partial, gt, p_fp, p_global_f,g_fp, g_global_f,sqrt=True):
    """loss function
    Args
        pcds_pred: List of predicted point clouds, order in [Pc, P1, P2, P3...]
    """
    if sqrt:
        CD = chamfer_sqrt
        PM = chamfer_single_side_sqrt
    else:
        CD = chamfer
        PM = chamfer_single_side
    # -------------------MSE-----------------------#
    mse1 = F.mse_loss(p_fp,g_fp)
    mse2 = F.mse_loss(p_global_f,g_global_f)
    # print("mse1:",mse1)
    # print("mse2:", mse2)


    #-------------------pyramid-----------------------#
    Pc, P1, P2, P3 = pcds_pred
    #gt.shape[1] 2048上

    # gt_3 = gt
    # gt_2 = fps_subsample(gt, P2.shape[1])
    # gt_1 = fps_subsample(gt_2, P1.shape[1])
    # gt_c = fps_subsample(gt_1, Pc.shape[1])

    #gt.shape[1] 2048下
    # print("P2.shape[1]:",P2.shape[1])#2048
    gt_3 = gt
    if gt.shape[1]<P2.shape[1]:
        gt_2=gt
    else:
        gt_2 = fps_subsample(gt, P2.shape[1])
    if gt_2.shape[1]<P1.shape[1]:
        gt_1=gt_2
    else:
        gt_1 = fps_subsample(gt_2, P1.shape[1])
    if gt_1.shape[1]<Pc.shape[1]:
        gt_c=gt_1
    else:
        gt_c = fps_subsample(gt_1, Pc.shape[1])

   

    

    cdc = CD(Pc, gt_c) 
    cd1 = CD(P1, gt_1) 
    cd2 = CD(P2, gt_2) 
    cd3 = CD(P3, gt_3)

    loss_decoder = cdc + cd1 + cd2 +cd3 +mse1 +mse2


    partial_matching = cdc #PM(partial, P1)
    

    loss_all = (loss_decoder) * 1e3 



    losses = [cdc, cd1, cd2, cd3, partial_matching, mse1, mse2]
    return loss_all, losses, [gt, gt_c, gt_c]


def mine_get_loss_clamp_PCN(pcds_pred, gt, sqrt=True):
    """loss function
    Args
        pcds_pred: List of predicted point clouds, order in [Pc, P1, P2, P3...]
    """
    if sqrt:
        CD = chamfer_sqrt
        PM = chamfer_single_side_sqrt
    else:
        CD = chamfer
        PM = chamfer_single_side

    # -------------------pyramid-----------------------#

    cdc = CD(pcds_pred, gt)



    CD_loss = (cdc) * 1e3


    return CD_loss

def mine_get_loss_clamp_PCN_PM(pcds_pred, gt, sqrt=True):
    """loss function
    Args
        pcds_pred: List of predicted point clouds, order in [Pc, P1, P2, P3...]
    """
    if sqrt:
        CD = chamfer_sqrt
        PM = chamfer_single_side_sqrt
    else:
        CD = chamfer
        PM = chamfer_single_side

    # -------------------pyramid-----------------------#
    #pcds_pred-> gt 单向
    #pcds_pred 中每个点到 gt 中最近点的距离
    cdc = PM(pcds_pred, gt)

    CD_loss = (cdc) * 1e3


    return CD_loss

def mine_get_loss_clamp_G(pcds_pred, gt, sqrt=True):
    """loss function
    Args
        pcds_pred: List of predicted point clouds, order in [Pc, P1, P2, P3...]
    """
    if sqrt:
        CD = chamfer_sqrt
        PM = chamfer_single_side_sqrt
    else:
        CD = chamfer
        PM = chamfer_single_side


    # -------------------pyramid-----------------------#


    # cdc = CD(pcds_pred, gt)#有真值的数据集 2
    # 没有真值的数据集 2 UCD
    cdc = PM(gt, pcds_pred)





    CD_loss = (cdc) * 1e3


    return CD_loss


def remove_outlier_points_tensor(pcd_tensor,device, ratio=1.5, min_points=512):
    """
    删除点云张量中的异常点，并确保每个点云至少有512个点。

    参数:
    - pcd_tensor: torch.Tensor, 形状为（B，N，3）的点云张量，其中B是批次大小，N是点的数量。
    - ratio: 距离阈值的倍数，用于确定是否删除点。
    - min_points: 每个点云必须保留的最小点数。

    返回:
    - cleaned_tensor: 清洗后的点云张量。
    """
    B, N, _ = pcd_tensor.shape

    # 将tensor转换为open3d的PointCloud对象
    pcd_list = [o3d.geometry.PointCloud() for _ in range(B)]
    for i, pcd in enumerate(pcd_list):
        pcd.points = o3d.utility.Vector3dVector(pcd_tensor[i].detach().cpu().numpy())

    # 计算每个点到其最近邻点的距离
    distances = [pcd.compute_nearest_neighbor_distance() for pcd in pcd_list]

    # 确定距离阈值
    thresholds = [mean_dist * ratio for mean_dist in np.mean([d for d in distances if d != 0], axis=0)]

    # 过滤掉异常点，并确保每个点云至少有min_points个点
    final_pcd_list = []
    for pcd, distances, threshold in zip(pcd_list, distances, thresholds):
        filtered_indices = [i for i, d in enumerate(distances) if d < threshold]
        if len(filtered_indices) < min_points:
            # 如果过滤后的点数少于min_points，则选择距离最小的min_points个点
            filtered_indices = np.argsort(distances)[:min_points].tolist()
        cleaned_pcd = pcd.select_by_index(filtered_indices)
        f_point =torch.from_numpy(np.asarray(cleaned_pcd.points)).unsqueeze(0).float().to(device)#(N,3) (1,n,3)
        # print("f_point.shape",f_point.shape)
        fps_point_ = pointops.fps(f_point, min_points)
        # print("fps_point_.shape", fps_point_.shape)

        final_pcd_list.append(fps_point_)

    final_pcd_ = torch.cat(final_pcd_list, dim=0)

    return final_pcd_



class SubLoss(nn.Module):
    def __init__(self, reduction='mean'):
        super(SubLoss, self).__init__()
        self.criterion = nn.KLDivLoss(reduction='none')
        self.reduction = reduction

    def forward(self, output, target, target_weight=None):
        B, _ = output.shape  # 获取 batch size 和特征维度
        heatmaps_pred = output.reshape((B, -1))  # 保持形状为 (B, 1024)
        mark_i = torch.argmax(heatmaps_pred, dim=-1)  # 找到预测的最大值索引

        heatmaps_gt = target.reshape((B, -1))  # 保持形状为 (B, 1024)
        mark_j = torch.argmax(heatmaps_gt, dim=-1)  # 找到目标的最大值索引

        # 创建掩码，将最大值位置置为0
        mask = torch.ones_like(heatmaps_pred)
        mask[torch.arange(B), mark_i] = 0
        mask[torch.arange(B), mark_j] = 0
        heatmaps_pred *= mask
        heatmaps_gt *= mask

        # 对预测和目标进行 log_softmax 操作
        heatmaps_pred = F.log_softmax(heatmaps_pred, dim=-1)
        heatmaps_gt = F.log_softmax(heatmaps_gt, dim=-1)

        # 计算 KL 散度损失
        loss = self.criterion(heatmaps_pred, heatmaps_gt).sum(dim=-1)

        # 如果提供了 target_weight，则对损失进行加权
        if target_weight is not None:
            loss = loss * target_weight.view((B,))

        # 根据 reduction 参数返回相应的损失值
        if self.reduction == 'mean':
            return loss.mean()
        elif self.reduction == 'none':
            return loss



def mask_top_k_joint(output, target, k=5):
    """
    将 output 和 target 的前 k 个最大值索引对应的位置在 output 和 target 中都置为 0。

    参数:
        output (torch.Tensor): 模型输出，形状为 (B, 1024)。
        target (torch.Tensor): 目标值，形状为 (B, 1024)。
        k (int): 要置为 0 的最大值数量，默认为 5。

    返回:
        output_masked (torch.Tensor): 处理后的 output，形状为 (B, 1024)。
        target_masked (torch.Tensor): 处理后的 target，形状为 (B, 1024)。
    """
    B, _ = output.shape  # 获取 batch size 和特征维度

    # 找到 output 的前 k 个最大值索引
    _, topk_indices_output = torch.topk(output, k=k, dim=-1)  # (B, k)

    # 找到 target 的前 k 个最大值索引
    _, topk_indices_target = torch.topk(target, k=k, dim=-1)  # (B, k)

    # 创建掩码，初始化为全 1
    mask_output = torch.ones_like(output)  # 全 1 掩码
    mask_target = torch.ones_like(target)  # 全 1 掩码

    # 将 output 的前 k 个最大值索引对应的位置在 output 和 target 中都置为 0
    for i in range(B):
        mask_output[i, topk_indices_output[i]] = 0  # output 的掩码
        mask_target[i, topk_indices_output[i]] = 0  # target 的掩码

    # 将 target 的前 k 个最大值索引对应的位置在 output 和 target 中都置为 0
    for i in range(B):
        mask_output[i, topk_indices_target[i]] = 0  # output 的掩码
        mask_target[i, topk_indices_target[i]] = 0  # target 的掩码

    # 应用掩码
    output_masked = output * mask_output
    target_masked = target * mask_target

    return output_masked, target_masked