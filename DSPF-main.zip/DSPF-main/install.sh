#!/usr/bin/env sh


# Chamfer Distance
cd ../extensions/chamfer_dist
python setup.py install --user

cd ../extensions/pointops
python setup.py install --user


cd ../Chamfer3D
python setup.py install
