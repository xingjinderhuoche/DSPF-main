
import os
import heapq

os.environ['CUDA_VISIBLE_DEVICES'] = '1'
import argparse
import os
import numpy as np
import torch
import json
import time
import utils.target_loaders
from easydict import EasyDict as edict
from importlib import import_module
from pprint import pprint
from run_adaptation import Manager_adaptation
from utils.average_meter import AverageMeter
from utils.metrics import Metrics
from utils.loss_utils_clamp import mine_get_loss_clamp_PCN

import math
# from models.crapcn import CRAPCN, CRAPCN_d
# from models.mine_models import mine_model_C, Mine_Discriminate
from models.our_models import our_model

TRAIN_NAME = os.path.splitext(os.path.basename(__file__))[0]




# Configuration for PCN
def PCNConfig():
    __C = edict()
    cfg = __C

    #
    # Dataset Config
    #
    __C.DATASETS = edict()
    __C.DATASETS.COMPLETION3D = edict()
    # __C.DATASETS.COMPLETION3D.CATEGORY_FILE_PATH = './datasets/Completion3D.json'
    # __C.DATASETS.COMPLETION3D.PARTIAL_POINTS_PATH = '/path/to/datasets/Completion3D/%s/partial/%s/%s.h5'
    # __C.DATASETS.COMPLETION3D.COMPLETE_POINTS_PATH = '/path/to/datasets/Completion3D/%s/gt/%s/%s.h5'
    __C.DATASETS.SHAPENET = edict()
    # __C.DATASETS.SHAPENET.CATEGORY_FILE_PATH = './datasets/MineRealComSNData.json'  # MineRealComSNData_chair.json
    __C.DATASETS.SHAPENET.N_RENDERINGS = 1  # 采样点个数
    __C.DATASETS.SHAPENET.N_POINTS = 2048  # 2048

    # __C.DATASETS.SHAPENET.PARTIAL_POINTS_PATH        =  './data/cra/%s/partial/%s/%s/%02d.pcd'
    # __C.DATASETS.SHAPENET.COMPLETE_POINTS_PATH       =  './data/cra/%s/complete/%s/%s.pcd'
    # __C.DATASETS.SHAPENET.PARTIAL_POINTS_PATH = '/home/haifeng/xzq/PP/CRA-PCN-main/data/DA/MineRealComSNData/%s/partial/%s/%s/%02d.pcd'
    # __C.DATASETS.SHAPENET.COMPLETE_POINTS_PATH = '/home/haifeng/xzq/PP/CRA-PCN-main/data/DA/MineRealComSNData/%s/complete/%s/%s.pcd'

    #
    # Dataset
    #
    __C.DATASET = edict()
    # Dataset Options: Completion3D, ShapeNet, ShapeNetCars, Completion3DPCCT
    __C.DATASET.TRAIN_DATASET = 'ModelNet'#'epn' 'ModelNet'
    __C.DATASET.TEST_DATASET = 'ModelNet'#'epn' 'ModelNet'

    #
    # Constants
    #
    __C.CONST = edict()

    __C.CONST.NUM_WORKERS = 8
    __C.CONST.N_INPUT_POINTS = 2048  # 2048

    #
    # Directories
    #

    __C.DIR = edict()
    __C.DIR.OUT_PATH = 'results/'
    __C.DIR.TEST_PATH = 'test/cra'
    __C.CONST.DEVICE = '1'
    __C.CONST.WEIGHTS                                = './results/pcn_pre_train_{cate}/checkpoints/ckpt-best.pth'#'./results/pcn_pre_train_chair/checkpoints/ckpt-best.pth'
    # __C.CONST.WEIGHTS_D = './pretrain/pcn/ckpt-bestD.pth'

    #
    # Network
    #
    __C.NETWORK = edict()
    __C.NETWORK.UPSAMPLE_FACTORS = [2, 2, 1, 8]  # 16384 [2, 2, 1, 8]
    __C.NETWORK.KP_EXTENTS = [0.1, 0.1, 0.05, 0.025]  # 16384 [0.1, 0.1, 0.05, 0.025]
    #
    # Train
    #
    __C.TRAIN = edict()
    __C.TRAIN.BATCH_SIZE = 30
    __C.TRAIN.N_EPOCHS = 300#300
    __C.TRAIN.SAVE_FREQ = 25
    __C.TRAIN.LEARNING_RATE = 0.0001  # 0.0001
    __C.TRAIN.LR_MILESTONES = [50, 100, 150, 200, 250]
    __C.TRAIN.LR_DECAY_STEP = 50
    __C.TRAIN.WARMUP_STEPS = 200  # 200
    __C.TRAIN.WARMUP_EPOCHS = 20
    __C.TRAIN.GAMMA = .5
    __C.TRAIN.BETAS = (.9, .999)
    __C.TRAIN.WEIGHT_DECAY = 0
    __C.TRAIN.LR_DECAY = 150

    #
    # Test
    #
    __C.TEST = edict()
    __C.TEST.METRIC_NAME = 'ChamferDistance'

    #
    # mine_model_G
    #
    __C.num_group = 64
    __C.group_size = 32
    __C.mask_ratio = [15, 39, 10]
    __C.feat_dim = 1024
    __C.n_points = 2048
    __C.nbr_ratio = 2.0  # 2
    __C.shape_recon_weight = 1000
    __C.shape_matching_weight = 1000
    __C.latent_weight = 100

    __C.PARTIAL_POINTS_PATH = '/media/haifeng/Data/ZhiQian/EPN3D/%s/partial/%s.npy'
    __C.COMPLETE_POINTS_PATH = '/media/haifeng/Data/ZhiQian/EPN3D/%s/complete/%s.npy'
    __C.CATEGORY_FILE_PATH = './data/EPN3D/EPN3D.json'

    __C.modelnet_PATH = '/media/haifeng/88ee5152-40be-4551-8ce0-77751544a78f/文件/ZhiQian/optde_data/processed_dataset/ModelNet40_Completion'

    __C.sub_weight = 0.3
    __C.con_weight = 0.9
    __C.pri_weight = 1
    __C.k_num = 10
    __C.k_pri_num = 10



    __C.domain = edict()
   
    __C.domain.category = 'sofa'#'table'


    return cfg


def adaptation_net(cfg):
    torch.backends.cudnn.benchmark = True

    train_dataset_loader = utils.target_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TRAIN_DATASET](cfg)
    val_dataset_loader = utils.target_loaders.DATASET_LOADER_MAPPING[cfg.DATASET.TEST_DATASET](cfg)

    train_data_loader = torch.utils.data.DataLoader(dataset=train_dataset_loader.get_dataset(
        utils.target_loaders.DatasetSubset.TRAIN),
        batch_size=cfg.TRAIN.BATCH_SIZE,
        num_workers=cfg.CONST.NUM_WORKERS,
        collate_fn=utils.target_loaders.collate_fn,
        pin_memory=True,
        shuffle=True,
        drop_last=False)
    val_data_loader = torch.utils.data.DataLoader(dataset=val_dataset_loader.get_dataset(
        utils.target_loaders.DatasetSubset.TEST),
        batch_size=cfg.TRAIN.BATCH_SIZE,
        num_workers=cfg.CONST.NUM_WORKERS // 2,
        collate_fn=utils.target_loaders.collate_fn,
        pin_memory=True,
        shuffle=False)

    # Set up folders for logs and checkpoints
    timestr = time.strftime('_Log_%Y_%m_%d_%H_%M_%S', time.gmtime())
    cfg.DIR.OUT_PATH = os.path.join(cfg.DIR.OUT_PATH, TRAIN_NAME + timestr)
    cfg.DIR.CHECKPOINTS = os.path.join(cfg.DIR.OUT_PATH, 'checkpoints')
    cfg.DIR.LOGS = cfg.DIR.OUT_PATH
    print('Saving outdir: {}'.format(cfg.DIR.OUT_PATH))
    if not os.path.exists(cfg.DIR.CHECKPOINTS):
        os.makedirs(cfg.DIR.CHECKPOINTS)


    model_sr = our_model()  # or 'CRAPCN_d'
    if torch.cuda.device_count() > 1:  # 检查电脑是否有多块GPU
        print(f"Let's use {torch.cuda.device_count()} GPUs!")
    if torch.cuda.is_available():
        model_sr = torch.nn.DataParallel(model_sr).cuda()

    # load existing model
    if 'WEIGHTS' in cfg.CONST:
        print('Recovering sr from %s ...' % (cfg.CONST.WEIGHTS))
        checkpoint = torch.load(cfg.CONST.WEIGHTS)
        model_sr.load_state_dict(checkpoint['model'], strict=True)
        print('Recover complete. Current epoch = #%d; best metrics = %s.' % (
        checkpoint['epoch_index'], checkpoint['best_metrics']))

    model_in = our_model()  # or 'CRAPCN_d'
    if torch.cuda.device_count() > 1:  # 检查电脑是否有多块GPU
        print(f"Let's use {torch.cuda.device_count()} GPUs!")
    if torch.cuda.is_available():
        model_in = torch.nn.DataParallel(model_in).cuda()

    # load existing model
    if 'WEIGHTS' in cfg.CONST:
        print('Recovering in from %s ...' % (cfg.CONST.WEIGHTS))
        checkpoint = torch.load(cfg.CONST.WEIGHTS)
        model_in.load_state_dict(checkpoint['model'], strict=True)
        print('Recover complete. Current epoch = #%d; best metrics = %s.' % (
        checkpoint['epoch_index'], checkpoint['best_metrics']))

    model_tg = our_model()  # or 'CRAPCN_d'
    if torch.cuda.device_count() > 1:  # 检查电脑是否有多块GPU
        print(f"Let's use {torch.cuda.device_count()} GPUs!")
    if torch.cuda.is_available():
        model_tg = torch.nn.DataParallel(model_tg).cuda()

    # load existing model
    if 'WEIGHTS' in cfg.CONST:
        print('Recovering tg from %s ...' % (cfg.CONST.WEIGHTS))
        checkpoint = torch.load(cfg.CONST.WEIGHTS)
        model_tg.load_state_dict(checkpoint['model'], strict=True)
        print('Recover complete. Current epoch = #%d; best metrics = %s.' % (
        checkpoint['epoch_index'], checkpoint['best_metrics']))
    ##################
    # Training Manager
    ##################


    manager = Manager_adaptation(model_sr, model_in, model_tg, cfg)

    # Start training
    best_in, best_tg, ucd_in, ucd_tg = manager.train(model_sr, model_in, model_tg, train_data_loader, val_data_loader, cfg)

    return best_in, best_tg, ucd_in, ucd_tg





def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


if __name__ == '__main__':
    
    # Arguments
    parser = argparse.ArgumentParser()

    parser.add_argument('--category', type=str, default='', help='category')
    parser.add_argument('--targetdata', type=str, default='', help='the path to target data')
    parser.add_argument('--sourcemodel', type=str, default='', help='the path to source model')
    parser.add_argument('--targetdatasets', type=str, default='ModelNet', help='')
    args = parser.parse_args()


    


    
    seed = 1128
    set_seed(seed)
    # print('cuda available ', torch.cuda.is_available())
    cfg = PCNConfig()

    cfg.domain.category = args.category

    cfg.CONST.WEIGHTS = args.sourcemodel
    cfg.DATASET.TRAIN_DATASET = args.targetdatasets
    cfg.DATASET.TEST_DATASET = args.targetdatasets

    if cfg.domain.category == 'airplane' and cfg.DATASET.TRAIN_DATASET == 'epn':
        cfg.domain.category = 'plane'
    
    adaptation_net(cfg)
   






