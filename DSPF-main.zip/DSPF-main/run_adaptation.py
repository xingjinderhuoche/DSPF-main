import os
import numpy as np
import torch
import torch.nn as nn
from torch.optim.lr_scheduler import StepLR
import time
from tqdm import tqdm
import utils.data_loaders
import utils.helpers
from utils.average_meter import AverageMeter
from utils.metrics import Metrics
from utils.schedular import GradualWarmupScheduler
from utils.loss_utils_clamp import get_loss_clamp, get_loss_mvp, mine_get_loss_clamp_PCN, mine_get_loss_clamp_G,mine_get_loss_clamp_PCN_PM,remove_outlier_points_tensor,mask_top_k_joint
from utils.ply import read_ply, write_ply
import pointnet_utils.pc_util as pc_util
from utils.mvp_utils import *
from PIL import Image
import scipy.linalg


from extensions.chamfer_dist import ChamferDistanceL1, ChamferDistanceL2

from models.transformer import Group
# from extensions.chamfer_dist import ChamferDistanceL1
from extensions.pointops.functions import pointops
from timm.models.layers import trunc_normal_
# from emd_ import emd_module


def gauss_(v1, v2, sigma):
    norm_ = torch.norm(v1 - v2, p=2, dim=0)
    return torch.exp(-0.5 * norm_ / sigma ** 2)


def euc_(v1, v2):
    return torch.norm(v1 - v2, p=2, dim=0)


def adj_(s, t, ap='cos'):
    # s, t [bsize, dim], [bsize, dim] -> [bsize, bsize]
    if ap == 'cos':
        s_norm = s / torch.norm(s, p=2, dim=1, keepdim=True)
        t_norm = t / torch.norm(t, p=2, dim=1, keepdim=True)
        adj = s_norm @ t_norm.T
    elif ap == 'gauss':
        sigma_ = 1.5
        M, N = s.shape[0], t.shape[0]
        adj = torch.zeros([M, N], dtype=torch.float).cuda()
        for i in range(M):
            for j in range(i):
                adj[i][j] = adj[j][i] = gauss_(s[i], t[j], sigma_)
    elif ap == 'euc':
        M, N = s.shape[0], t.shape[0]
        adj = torch.zeros([M, N], dtype=torch.float).cuda()
        for i in range(M):
            for j in range(i):
                adj[i][j] = adj[j][i] = euc_(s[i], t[j])
    return adj


def laplacian_(A, ltype='laplac1'):
    v = torch.sum(A, dim=1)
    if ltype == 'laplac1':
        v_inv = 1 / v
        D_inv = torch.diag(v_inv).cuda()
        return -D_inv @ A
    elif ltype == 'laplac2':
        D = torch.diag(v).cuda()
        return D - A
    elif ltype == 'laplac3':
        v_sqrt = 1 / torch.sqrt(v)
        D_sqrt = torch.diag(v_sqrt).cuda()
        I = torch.eye(A.shape[0]).cuda()
        return I - D_sqrt @ A @ D_sqrt



def svd_loss_(s, t, k_pri_num):
    # s, t [bsize, dim], [bsize, dim]
    s_matrix = adj_(s, s, 'euc')
    t_matrix = adj_(t, t, 'euc')
    s_matrix = laplacian_(s_matrix, 'laplac1')#([B,B])
    t_matrix = laplacian_(t_matrix, 'laplac1')

    _, s_v, _ = torch.linalg.svd(s_matrix)
    _, t_v, _ = torch.linalg.svd(t_matrix)

    svd_loss = torch.norm(s_v[:k_pri_num] - t_v[:k_pri_num], p=2)
    return svd_loss


#指数滑动平均
class OldWeightEMA (object):
    """
    Exponential moving average weight optimizer for mean teacher model
    """
    def __init__(self, target_net, source_net, alpha=0.999):
        self.target_params = list(target_net.parameters())
        self.source_params = list(source_net.parameters())
        self.alpha = alpha

        for p, src_p in zip(self.target_params, self.source_params):
            p.data[:] = src_p.data[:]

    def step(self):
        one_minus_alpha = 1.0 - self.alpha
        for p, src_p in zip(self.target_params, self.source_params):
            p.data.mul_(self.alpha)
            p.data.add_(src_p.data * one_minus_alpha)


class Manager_adaptation:
    # Initialization methods
    # ------------------------------------------------------------------------------------------------------------------
    def __init__(self, model_sr, model_in, model_tg, cfg):
        """
        Initialize parameters and start training/testing
        :param model: network object
        :param cfg: configuration object
        """

        ############
        # Parameters
        ############

        # Epoch index
        self.epoch = 0

        # SR只更新generator
        self.optimizer_sr = torch.optim.Adam(filter(lambda p: p.requires_grad, model_sr.module.generator.parameters()),
                                          lr=cfg.TRAIN.LEARNING_RATE,
                                          weight_decay=cfg.TRAIN.WEIGHT_DECAY,
                                          betas=cfg.TRAIN.BETAS)


        self.scheduler_steplr_sr = StepLR(self.optimizer_sr, step_size=1, gamma=0.1 ** (1 / cfg.TRAIN.LR_DECAY))
        self.lr_scheduler_sr = GradualWarmupScheduler(self.optimizer_sr, multiplier=1, total_epoch=cfg.TRAIN.WARMUP_EPOCHS,
                                                   after_scheduler=self.scheduler_steplr_sr)
        # In 只更新Encoder model_in.module.encoder.parameters()
        self.optimizer_in = torch.optim.Adam(filter(lambda p: p.requires_grad, model_in.parameters()),
                                             lr=cfg.TRAIN.LEARNING_RATE*0.1,
                                             weight_decay=cfg.TRAIN.WEIGHT_DECAY,
                                             betas=cfg.TRAIN.BETAS)

        self.scheduler_steplr_in = StepLR(self.optimizer_in, step_size=1, gamma=0.1 ** (1 / cfg.TRAIN.LR_DECAY))
        self.lr_scheduler_in = GradualWarmupScheduler(self.optimizer_in, multiplier=1,
                                                      total_epoch=cfg.TRAIN.WARMUP_EPOCHS,
                                                      after_scheduler=self.scheduler_steplr_in)
        # tg 全更新
        self.optimizer_tg = torch.optim.Adam(filter(lambda p: p.requires_grad, model_tg.parameters()),
                                             lr=cfg.TRAIN.LEARNING_RATE,
                                             weight_decay=cfg.TRAIN.WEIGHT_DECAY,
                                             betas=cfg.TRAIN.BETAS)

        self.scheduler_steplr_tg = StepLR(self.optimizer_tg, step_size=1, gamma=0.1 ** (1 / cfg.TRAIN.LR_DECAY))
        self.lr_scheduler_tg = GradualWarmupScheduler(self.optimizer_tg, multiplier=1,
                                                      total_epoch=cfg.TRAIN.WARMUP_EPOCHS,
                                                      after_scheduler=self.scheduler_steplr_tg)

        self.ema_optimizer = OldWeightEMA(model_in, model_tg, alpha=0.999)  # 将model_tg里面的参数平移到model_in中


        # record file
        self.train_record_file = open(os.path.join(cfg.DIR.LOGS, 'training.txt'), 'w')
        self.test_record_file = open(os.path.join(cfg.DIR.LOGS, 'testing.txt'), 'w')

        # eval metric
        self.best_metrics = float('inf')
        self.best_metrics_tg = float('inf')
        self.best_one = float('inf')

        self.ucd_eval_in = float('inf')
        self.ucd_eval_tg = float('inf')



        self.best_epoch = 0
        self.best_epoch_tg = 0
        self.eps = 1e-8


        self.num_group = cfg.num_group
        self.group_size = cfg.group_size
        self.mask_ratio = cfg.mask_ratio
        self.nbr_ratio = cfg.nbr_ratio
        self.group_divider = Group(num_group=self.num_group, group_size=self.group_size)
        self.shape_criterion = ChamferDistanceL1()

        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


    def _group_points(self, nbrs, center, B, G):
        nbr_groups = []
        center_groups = []
        perm = torch.randperm(G)#随机排列,返回例如tensor([1, 5, 6, 8, 4, 0, 7, 2, 3, 9])的张量
        acc = 0
        for i in range(3):
            mask = torch.zeros(B, G, dtype=torch.bool, device=center.device)
            mask[:, perm[acc:acc+self.mask_ratio[i]]] = True
            nbr_groups.append(nbrs[mask].view(B, self.mask_ratio[i], self.group_size, -1))
            center_groups.append(center[mask].view(B, self.mask_ratio[i], -1))
            acc += self.mask_ratio[i]
        return nbr_groups, center_groups


    # Record functions
    def train_record(self, info, show_info=True):
        if show_info:
            print(info)
        if self.train_record_file:
            self.train_record_file.write(info + '\n')
            self.train_record_file.flush()

    def test_record(self, info, show_info=True):
        if show_info:
            print(info)
        if self.test_record_file:
            self.test_record_file.write(info + '\n')
            self.test_record_file.flush()

    def train(self, model_sr, model_in, model_tg, train_data_loader, val_data_loader, cfg):
        # self.train_dataset = train_data_loader
        # self.val_dataset = val_data_loader

        init_epoch = 0
        steps = 0

        # training record file
        print('Training Record:')
        self.train_record('CD_loss')
        print('Testing Record:')
        self.test_record('#epoch CD_loss')



        num_0 = 0
        Sub_Loss = nn.MSELoss()

        # Training Start
        for epoch_idx in range(init_epoch + 1, cfg.TRAIN.N_EPOCHS + 1):

            self.epoch = epoch_idx
            # print("epoch_idx:",epoch_idx)

            # timer
            epoch_start_time = time.time()

            model_sr.eval()
            model_in.train()
            # model_in.eval()
            model_tg.train()


            # Update learning rate
            self.lr_scheduler_sr.step()
            self.lr_scheduler_in.step()
            self.lr_scheduler_tg.step()


            # total cds
            total_cd = 0
            total_ploss = 0
            total_closs = 0



            batch_end_time = time.time()
            n_batches = len(train_data_loader)



            learning_rate = self.optimizer_sr.param_groups[0]['lr']

            for batch_idx,  data in enumerate(train_data_loader):# data

                for k, v in data.items():
                    data[k] = utils.helpers.var_or_cuda(v)


                # unpack data
                partial = data['partial']
                # gt = data['complete']
               
               

                # STEP B 
                model_in.eval()
                model_tg.train()
                # model_sr.eval()
                nbrs, center = self.group_divider(partial)  # neighborhood [B, G, [K], C], center B G 3
                B, G, _ = center.shape
                nbr_groups, center_groups = self._group_points(nbrs, center, B, G)  # 形状3的列表
                rebuild_points0 = (nbr_groups[0] + center_groups[0].unsqueeze(-2)).reshape(B, -1, 3)
               
                rebuild_points1 = (nbr_groups[1] + center_groups[1].unsqueeze(-2)).reshape(B, -1, 3)  # K1
             
                rebuild_points2 = (nbr_groups[2] + center_groups[2].unsqueeze(-2)).reshape(B, -1, 3)  # K2

                partial_input = torch.cat((rebuild_points0, rebuild_points1), dim=1)

               
                y_course_in = model_in(partial_input)
                y_feature_tg = model_tg.module.encoder(partial_input)
                y_course_tg = model_tg.module.generator(y_feature_tg)


                idx = pointops.knn(center_groups[2], y_course_tg, int(self.nbr_ratio * self.group_size))[0]
                nbrs_pred = pointops.index_points(y_course_tg, idx).reshape(B, -1, 3)  # (B, -1, 3),与输入对应的点的重建误差

                loss_rcd_b = mine_get_loss_clamp_PCN(rebuild_points2.reshape(B, -1, 3), nbrs_pred, sqrt=True)
                loss_cd_b = mine_get_loss_clamp_PCN(y_course_tg, y_course_in, sqrt=True)  # CD

                l2_reg = 0.01*torch.norm(y_feature_tg, p=2)

                loss_tg = cfg.con_weight*loss_cd_b + loss_rcd_b + l2_reg
               

                self.optimizer_tg.zero_grad()
                loss_tg.backward()
                self.optimizer_tg.step()

                self.ema_optimizer.step()

                # STEP A
                # 更新 in
                model_in.train()
                model_tg.eval()

                feature_sr = model_sr.module.encoder(partial)
                feature_in = model_in.module.encoder(partial)
                por_feature_sr,por_feature_in = mask_top_k_joint(feature_sr,feature_in, cfg.k_num)
                y_por_sr = model_sr.module.generator(por_feature_sr)
                y_por_in = model_in.module.generator(por_feature_in)
                loss_cd_a_3 = mine_get_loss_clamp_PCN(y_por_sr, y_por_in, sqrt=True)
               
                loss_gsa = svd_loss_(feature_sr, feature_in, cfg.k_pri_num)

 
                loss_in = cfg.sub_weight*loss_cd_a_3 + cfg.pri_weight * loss_gsa
                

               
                self.optimizer_in.zero_grad()
                loss_in.backward()
                self.optimizer_in.step()


                cd_item = 0.3*loss_cd_b#loss_cd_a_1
                total_cd += cd_item
                ploss_item = loss_rcd_b
                total_ploss += ploss_item
                closs_item =  l2_reg
                total_closs += closs_item


                n_itr = (epoch_idx - 1) * n_batches + batch_idx

                # training record
                message = '{:d} {:.4f} {:.4f}'.format(n_itr,cd_item, total_cd)
                self.train_record(message, show_info=False)


            # avg cds
            avg_cd = total_cd / n_batches
            avg_ploss = total_ploss / n_batches
            avg_closs = total_closs/ n_batches


            epoch_end_time = time.time()

            # Training record
            self.train_record(
                '[Epoch %d/%d] LearningRate = %f EpochTime = %.3f (s) 0.3*loss_cd_b = %f loss_rcd_b  = %f  l2_reg = %f ' %
                (epoch_idx, cfg.TRAIN.N_EPOCHS, learning_rate, epoch_end_time - epoch_start_time,
                 avg_cd,avg_ploss, avg_closs))



            # Validate the current model
            cd_eval = self.validate(cfg, model=model_in, val_data_loader=val_data_loader)

            cd_eval_tg = self.validate(cfg, model=model_tg, val_data_loader=val_data_loader)

           


            if cd_eval_tg < self.best_metrics_tg:

                self.best_epoch_tg = epoch_idx
                file_name = 'ckpt-best-tg.pth' if cd_eval_tg < self.best_metrics_tg else 'ckpt-epoch-%03d.pth' % epoch_idx
                output_path = os.path.join(cfg.DIR.CHECKPOINTS, file_name)
                torch.save({
                    'epoch_index': epoch_idx,
                    'best_metrics': cd_eval_tg,
                    'model': model_tg.state_dict()
                }, output_path)

                print('Saved tg checkpoint to %s ...' % output_path)

                self.best_metrics_tg = cd_eval_tg
                # self.ucd_eval_tg = ucd_eval_tg


            # Save checkpoints
            if cd_eval < self.best_metrics:
                self.best_epoch = epoch_idx
                file_name = 'ckpt-best-in.pth' if cd_eval < self.best_metrics else 'ckpt-epoch-%03d.pth' % epoch_idx
                output_path = os.path.join(cfg.DIR.CHECKPOINTS, file_name)
                torch.save({
                    'epoch_index': epoch_idx,
                    'best_metrics': cd_eval,
                    'model': model_in.state_dict()
                }, output_path)

                print('Saved in checkpoint to %s ...' % output_path)

                if cd_eval < self.best_metrics:
                    self.best_metrics = cd_eval


            # print('best tg: ', self.best_metrics_tg)
            # print('best in: ', self.best_metrics)
            # print('best tg_ucd: ', self.ucd_eval_tg)
            # print('best in_ucd: ', self.ucd_eval_in)

        # training end
        self.train_record_file.close()
        self.test_record_file.close()
        return self.best_metrics, self.best_metrics_tg, self.ucd_eval_in, self.ucd_eval_tg


    def validate(self, cfg, model=None, val_data_loader=None, outdir=None):
        # Enable the inbuilt cudnn auto-tuner to find the best algorithm to use
        torch.backends.cudnn.benchmark = True

        # Switch models to evaluation mode
        model.eval()

        n_samples = len(val_data_loader)
        test_losses = AverageMeter(['cdc'])
        test_metrics = AverageMeter(Metrics.names())

        # Start testing
        for model_idx, data in enumerate(val_data_loader):

            with torch.no_grad():
                for k, v in data.items():
                    data[k] = utils.helpers.var_or_cuda(v)

                # unpack data
                # partial = data['partial_cloud']
                # gt = data['gtcloud']
                partial = data['partial']
                gt = data['complete']
                # gt = data['sc_cloud']
                # print("---pcv:", partial.shape)
                # print("---gcv:", gt.shape)

                # forward
                # pcds_pred = model(partial.contiguous())
                # loss_total, losses, _ = get_loss_clamp(pcds_pred, partial, gt, sqrt=True)
                course = model(partial)

                loss_total = mine_get_loss_clamp_PCN(course, gt, sqrt=False)

                _metrics = [loss_total]
                test_losses.update([loss_total])
                test_metrics.update(_metrics)

        # Record testing results
        message = '#{:d} {:.4f}  |in #{:d} {:.4f}|tg #{:d} {:.4f}'.format(self.epoch,test_losses.avg(0), self.best_epoch, self.best_metrics, self.best_epoch_tg, self.best_metrics_tg)
        # print('best_epoch_tg:', self.best_epoch_tg)
        self.test_record(message)

        return test_losses.avg(0)

    def UCD_validate(self, cfg, model=None, val_data_loader=None, outdir=None):
        # Enable the inbuilt cudnn auto-tuner to find the best algorithm to use
        torch.backends.cudnn.benchmark = True

        # Switch models to evaluation mode
        model.eval()

        n_samples = len(val_data_loader)
        test_losses = AverageMeter(['cdc'])
        test_metrics = AverageMeter(Metrics.names())

        # Start testing
        for model_idx, data in enumerate(val_data_loader):

            with torch.no_grad():
                for k, v in data.items():
                    data[k] = utils.helpers.var_or_cuda(v)

                # unpack data
                # partial = data['partial_cloud']
                # gt = data['gtcloud']
                partial = data['partial']

                # gt = data['sc_cloud']
                # print("---pcv:", partial.shape)
                # print("---gcv:", gt.shape)

                # forward
                # pcds_pred = model(partial.contiguous())
                # loss_total, losses, _ = get_loss_clamp(pcds_pred, partial, gt, sqrt=True)


                course = model(partial)

                loss_total = mine_get_loss_clamp_PCN_PM(partial, course, sqrt=False)

                _metrics = [loss_total]
                test_losses.update([loss_total])
                test_metrics.update(_metrics)

        # Record testing results
        # message = '#{:d} {:.4f}  | #{:d} {:.4f}'.format(self.epoch,test_losses.avg(0), self.best_epoch, self.best_metrics)
        print('UCD :', test_losses.avg(0))
        # self.test_record(message)

        return test_losses.avg(0)



    def testone(self, cfg, model=None, test_data_loader=None, outdir=None):
        # Enable the inbuilt cudnn auto-tuner to find the best algorithm to use
        torch.backends.cudnn.benchmark = True

        # Switch models to evaluation mode
        model.eval()

        n_samples = len(test_data_loader)
        test_losses = AverageMeter(['cdc'])
        test_metrics = AverageMeter(Metrics.names())
        category_metrics = dict()
        category_models = dict()

        # Start testing
        for model_idx, (taxonomy_id, model_id, data) in enumerate(test_data_loader):
            taxonomy_id = taxonomy_id[0] if isinstance(taxonomy_id[0], str) else taxonomy_id[0].item()
            # model_id = model_id[0]

            with torch.no_grad():
                for k, v in data.items():
                    data[k] = utils.helpers.var_or_cuda(v)

                partial = data['partial_cloud']

                b, n, _ = partial.shape

                pcds_pred = model(partial.contiguous())


                # output to file
                if outdir:
                    if not os.path.exists(os.path.join(outdir, taxonomy_id)):
                        os.makedirs(os.path.join(outdir, taxonomy_id))
                    if not os.path.exists(os.path.join(outdir, taxonomy_id + '_images')):
                        os.makedirs(os.path.join(outdir, taxonomy_id + '_images'))
                    # save pred, gt, partial pcds
                    pred = pcds_pred
                    for mm, model_name in enumerate(model_id):
                        output_file = os.path.join(outdir, taxonomy_id, model_name)
                        write_ply(output_file + '_pred.ply', pred[mm, :].detach().cpu().numpy(), ['x', 'y', 'z'])
                        write_ply(output_file + '_partial.ply', partial[mm, :].detach().cpu().numpy(), ['x', 'y', 'z'])
