import sys
sys.path.append('../pointnet2_ops_lib')
sys.path.append('..')